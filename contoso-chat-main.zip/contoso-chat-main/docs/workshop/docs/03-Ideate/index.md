# 3. Ideate With Prompty

!!! success "Let's Review where we are right now"

    ![Dev Workflow](./../img/workshop-developer-flow.png)

    We should have organized our browser into these 5 tabs, for development:

    1. Skillable VM tag - showing the countdown timer & launch page
    1. GitHub Codespaces tab - showing the Visual Studio Code IDE.
    1. Azure Portal tab - showing your `rg-AITOUR` resource group.
    1. Azure AI Studio tab - showing your AI project page.
    1. Azure Container Apps - showing your deployed application.
    
    We completed the setup, validated the infrastructure and verified that the application was deployed correctly. 

_Now we can deconstruct the sample to learn how it works. Let's do this by understanding how we go from prompt to prototytpe in the **Ideate** stage, next._
